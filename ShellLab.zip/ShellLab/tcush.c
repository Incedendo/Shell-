//*********************************************************
//
// PUT YOUR NAME HERE!!!!
// Operating Systems
// Project #1: Writing Your Own Shell: tcush
//
//*********************************************************


//*********************************************************
//
// Includes and Defines
//
//*********************************************************
#include <errno.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <unistd.h>

#define STRMYQUIT "myquit"


//*********************************************************
//
// Type Declarations
//
//*********************************************************
typedef enum{ false, true } bool;


//*********************************************************
//
// Extern Declarations
//
//*********************************************************
extern char **gettoks();


//*********************************************************
//
// Function Prototypes
//
//*********************************************************



//*********************************************************
//
// Main Function
//
//*********************************************************
int main( int argc, char *argv[] )
{
  /* local variables */
  int ii;
  char **toks;
  int retval;

  /* initialize local variables */
  ii = 0;
  toks = NULL;
  retval = 0;

  /* put signal catching functions here */
  
  /* main (infinite) loop */
  while( true )
    {
      /* get arguments */
      toks = gettoks();

      if( toks[0] != NULL )
	{
	  /* simple loop to echo all arguments */
	  for( ii=0; toks[ii] != NULL; ii++ )
	    {
	      printf( "Argument %d: %s\n", ii, toks[ii] );
	    }

	  if( !strcmp( toks[0], STRMYQUIT ))
	    break;
	}
    }

  /* return to calling environment */
  return(retval);
}
